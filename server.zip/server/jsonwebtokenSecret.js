module.exports = {
  secret: 'somekeys'
};