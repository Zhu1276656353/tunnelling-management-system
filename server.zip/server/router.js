const express = require('express'); // 引入 Express 框架
const router = express.Router(); // 创建一个路由实例
const url = require("url"); // 引入 URL 模块
const sqlConnect = require("./sqlConnect"); // 引入自定义的数据库连接模块
const jsonwebtoken = require("jsonwebtoken"); // 引入 jsonwebtoken 模块用于生成和验证 token
const jsonwebtokenSecret = require("./jsonwebtokenSecret.js"); // 引入 token 的密钥配置
const adminData = require("./data/admin.js");// 引入管理员数据
const vipData = require("./data/vip.js"); // 引入 VIP 数据
const lineData = require("./data/line.js"); // 线条数据
const pieData = require("./data/pie.js"); // 引入饼图数据
const radarData = require("./data/radar.js"); // 引入雷达图数据
const barData = require("./data/bar.js"); // 引入柱状图数据
const multer = require("multer");// 文件上传
const fs = require("fs");
/**
 * 用户登录接口
 * 接收 POST 请求，路径为 /login
 */
router.post("/login", (req, res) => {
    // 从请求体中获取用户名和密码
    const { username, password } = req.body;
    // 查询数据库，检查用户名和密码是否匹配
    const sql = `select * from user where username = ? and password = ?`;

    // 执行 SQL 查询
    sqlConnect(sql, [username, password], result => {
        if (result.length > 0) {
            /**
             * 生成 token：用于前后端登录状态验证
             * token 中包含用户的基本信息（id、username、permission）
             */
            const token = jsonwebtoken.sign({
                id: result[0].id,
                username: result[0].username,
                permission: result[0].permission
            }, jsonwebtokenSecret.secret); // 使用密钥加密生成 token

            // 登录成功，返回用户信息和 token
            res.send({
                status: 200,
                username: result[0].username,
                permission: result[0].permission,
                token
            });
        } else {
            // 用户名或密码错误，返回错误信息
            res.send({
                status: 500,
                msg: "用户名或密码错误"
            });
        }
    });
});
/**
 * 用户权限管理
 */
router.get("/router", (req, res) => {
    const user = url.parse(req.url, true).query.user;
    switch (user) {
        case "admin":
            res.send({
                status: 200,
                menuData: adminData
            })
            break;
        case "vip":
            res.send({
                status: 200,
                menuData: vipData
            })
            break;
        default:
            res.send({
                status: 200,
                menuData: vipData
            })
            break;
    }
})

// 获取线条数据
router.get("/lineData", (req, res) => {
    res.send({
        status: 200,
        result: lineData
    })
})
//获取饼图数据
router.get("/pieData", (req, res) => {
    res.send({
        status: 200,
        result: pieData
    })
})
//获取雷达图数据
router.get("/radarData", (req, res) => {
    res.send({
        status: 200,
        result: radarData
    })
})
//获取柱状图数据
router.get("/barData", (req, res) => {
    res.send({
        status: 200,
        result: barData
    })
})
/**
 * 隧道信息查询
 */
router.get("/project/all", (req, res) => {
    //分页
    var page = url.parse(req.url, true).query.page || 1; // 获取当前页码，默认为1
    const sql = `select * from project order by id desc limit 15 offset ${(page - 1) * 15}`; // 查询15条隧道信息，按 ID 降序排列，每页10条数据
    sqlConnect(sql, null, result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                result
            })
        } else {
            res.send({
                status: 500,
                msg: '暂无数据'
            })
        }
    })
})
//隧道模糊查询接口
router.get("/project/search", (req, res) => {
    //接受参数:查询内容
    const search = url.parse(req.url, true).query.search;
    //模糊查询sql语句
    const sql = "select * from project where concat(`name`,`address`,`remark`) like '%" + search + "%'";
    sqlConnect(sql, null, result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                result
            })
        } else {
            res.send({
                status: 500,
                msg: '暂无数据'
            })
        }
    })
})
//获得页码总页数
router.get("/project/total", (req, res) => {
    const sql = "select count(*) from project where id";// 查询总记录数
    sqlConnect(sql, null, result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                result
            })
        } else {
            res.send({
                status: 500,
                msg: '暂无数据'
            })
        }
    })
})
//隧道添加
router.get("/project/add", (req, res) => {
    var name = url.parse(req.url, true).query.name || "";
    var number = url.parse(req.url, true).query.number || "";
    var money = url.parse(req.url, true).query.money || "";
    var adress = url.parse(req.url, true).query.adress || "";
    var duration = url.parse(req.url, true).query.duration || "";
    var startTime = url.parse(req.url, true).query.startTime || "";
    var endTime = url.parse(req.url, true).query.endTime || "";
    var quantity = url.parse(req.url, true).query.quantity || "";
    var status = url.parse(req.url, true).query.status || "";
    var remark = url.parse(req.url, true).query.remark || "";
    const sql = "insert into project values(null,?,?,?,?,?,?,?,?,?,?)"
    const arr = [name, number, money, adress, duration, startTime, endTime, quantity, status, remark]
    sqlConnect(sql, arr, result => {
        if (result.affectedRows > 0) {
            res.send({
                status: 200,
                msg: '添加成功'
            })
        } else {
            res.send({
                status: 500,
                msg: '添加失败'
            })
        }
    })
})
//隧道数据删除
router.get("/project/delete", (req, res) => {
    var id = url.parse(req.url, true).query.id;
    const sql = "delete from project where id=?"
    sqlConnect(sql, [id], result => {
        if (result.affectedRows > 0) {
            res.send({
                status: 200,
                msg: '删除成功'
            })
        } else {
            res.send({
                status: 500,
                msg: '删除失败'
            })
        }
    })
})
//隧道预更新
router.get("/project/preUpdate", (req, res) => {
    var id = url.parse(req.url, true).query.id;
    const sql = "select * from project where id=?"
    sqlConnect(sql, [id], result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                result
            })
        } else {
            res.send({
                status: 500,
                msg: '暂无数据'
            })
        }
    })
})
//修改隧道数据
router.put("/project/update/:id", (req, res) => {
    const id = req.params.id;
    const { name, number, money, address, duration, startTime, endTime, quantity, status, remark } = req.body;
    const sql = "update project set name=?,number=?,money=?,address=?,duration=?,startTime=?,endTime=?,quantity=?,status=?,remark=? where id=?"
    const arr = [name, number, money, address, duration, startTime, endTime, quantity, status, remark, id]
    sqlConnect(sql, arr, result => {
        if (result.affectedRows > 0) {
            res.send({
                status: 200,
                msg: '修改成功'
            })
        } else {
            res.send({
                status: 500,
                msg: '修改失败'
            })
        }
    })
})
//隧道设计信息 tree列表 一级
router.get("/tunnel/list", (req, res) => {
    const sql = "select * from tunnel"
    sqlConnect(sql, null, result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                result
            })
        } else {
            res.send({
                status: 500,
                msg: '暂无数据'
            })
        }
    })
})
//隧道设计信息 tree列表 二级
router.get("/tunnel/list/child", (req, res) => {
    const cid = url.parse(req.url, true).query.cid;
    const sql = "select * from tunnelchild where cid = ?"
    sqlConnect(sql, [cid], result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                result
            })
        } else {
            res.send({
                status: 500,
                msg: '暂无数据'
            })
        }
    })
})
//隧道设计信息 内容
router.get("/tunnel/content", (req, res) => {
    const content = url.parse(req.url, true).query.content;
    const sql = "select * from tunnelcontent where content = ?"
    sqlConnect(sql, [content], result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                result
            })
        } else {
            res.send({
                status: 500,
                msg: '暂无数据'
            })
        }
    })
})
//文件上传
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, "./upload/")
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + "-" + file.originalname)
    }
})

var createFolder = function (folder) {
    try {
        fs.accessSync(folder);
    } catch (e) {
        fs.mkdirSync(folder);
    }
}

var uploadFolder = './upload/';
createFolder(uploadFolder);
var upload = multer({ storage: storage });

router.post('/upload', upload.single('file'), function (req, res, next) {
    var file = req.file;
    console.log('文件类型：%s', file.mimetype);
    console.log('原始文件名：%s', file.originalname);
    console.log('文件大小：%s', file.size);
    console.log('文件保存路径：%s', file.path);
    res.json({ res_code: '0', name: file.originalname, url: file.path });
});
//更新隧道设计信息内容-content-url
router.get("/tunnel/content/url", (req, res) => {
    //id url
    const id = url.parse(req.url, true).query.id;
    const urlName = url.parse(req.url, true).query.urlName;
    const sql = "update tunnelcontent set urlName=? where id=?"
    sqlConnect(sql, [urlName, id], result => {
        if (result.affectedRows > 0) {
            res.send({
                status: 200,
                msg: "上传成功"
            })
        } else {
            res.send({
                status: 500,
                msg: "上传失败"
            })
        }
    })
})
//预览pdf
router.get("/tunnel/pdf", (req, res) => {
    const id = url.parse(req.url, true).query.id;
    const sql = "select * from tunnelcontent where id=?"
    sqlConnect(sql, [id], result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                msg: "获取成功",
                result: result[0]
            })
        } else {
            res.send({
                status: 500,
                msg: "获取失败"
            })
        }
    })
})
//查询用户列表
router.get("/user/list", (req, res) => {
    const sql = "select * from user"
    sqlConnect(sql, null, result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                msg: "获取成功",
                result: result
            })
        } else {
            res.send({
                status: 500,
                msg: "暂无数据"
            })

        }
    })
})
//搜索用户
router.get("/user/search", (req, res) => {
    const search = url.parse(req.url, true).query.search;
    const sql = "select * from user where concat(`username`,`permission`,`phone`) like '%" + search + "%'"
    sqlConnect(sql, null, result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                msg: "获取成功",
                result: result
            })
        } else {
            res.send({
                status: 500,
                msg: "暂无数据"
            })
        }
    })
})
//添加用户信息
router.get("/user/add", (req, res) => {
    const username = url.parse(req.url, true).query.username;
    const password = url.parse(req.url, true).query.password;
    const permission = url.parse(req.url, true).query.permission;
    const phone = url.parse(req.url, true).query.phone;
    const sql = `insert into user values(null,?,?,?,?)`;
    sqlConnect(sql, [username, password, permission, phone], result => {
        if (result.affectedRows > 0) {
            res.send({
                status: 200,
                msg: "添加成功"
            })
        } else {
            res.send({
                status: 500,
                msg: "添加失败"
            })
        }
    })
})
//删除用户
router.get("/user/delete", (req, res) => {
    const id = url.parse(req.url, true).query.id;
    if (id == 1) {
        return
    }
    const sql = "delete from user where id = ?";
    sqlConnect(sql, [id], result => {
        if (result.affectedRows > 0) {
            res.send({
                status: 200,
                msg: "删除成功"
            })
        } else {
            res.send({
                status: 500,
                msg: "删除失败"
            })
        }
    })
})
//用户预更新
router.get("/user/preview", (req, res) => {
    const id = url.parse(req.url, true).query.id;
    const sql = "select * from user where id = ?";
    sqlConnect(sql, [id], result => {
        if (result.length > 0) {
            res.send({
                status: 200,
                result: result[0]
            })
        } else {
            res.send({
                status: 500,
                msg: "查询失败"
            })
        }
    })
})
//用户更新
router.get("/user/update", (req, res) => {
    const id = url.parse(req.url, true).query.id;
    const password = url.parse(req.url, true).query.password;
    const permission = url.parse(req.url, true).query.permission;
    const phone = url.parse(req.url, true).query.phone;
    const sql = "update user set password=?,permission=?,phone=? where id=?";
    sqlConnect(sql, [ password, permission, phone, id], result => {
        if (result.affectedRows > 0) {
            res.send({
                status: 200,
                msg: "更新成功"
            })
        } else {
            res.send({
                status: 500,
                msg: "更新失败"
            })
        }
    })
})
// 导出路由实例
module.exports = router;