const express = require('express');
const app = express();
const router = require('./router.js');
const bodyParser = require('body-parser');//获取post请求
const cors = require('cors');//解决跨域

//解决跨域
app.use(cors());
//获取post请求
app.use(bodyParser.urlencoded({
    extended: true
}))
app.use("/api", router);
app.use(express.static("upload"))

app.listen(3000, () => {
    console.log('服务器在3000端口上运行')
});