module.exports = {
    menus: [
        {
            path: "/",
            name: "首页",
            icon: "Document"
        },
        {
            path: "/projectInfo",
            name: "项目基础信息",
            icon: "Discount"
        },
        {
            path: "/tunnelInfo",
            name: "隧道设计信息",
            icon: "Picture"
        },
        // {
        //     path: "/buildManageInfo",
        //     name: "施工监控检测",
        //     icon: "Filter",
        //     children: [
        //         {
        //             path: "/plan",
        //             name: "检测计划"
        //         },
        //         {
        //             path: "/section",
        //             name: "切面检测"
        //         }
        //     ]
        // },
        {
            path: "/geographyInfo",
            name: "超前地质预报",
            icon: "ShoppingTrolley"
        },
        {
            path: "/systemManage",
            name: "系统信息管理",
            icon: "Wallet"
        }
    ]
}