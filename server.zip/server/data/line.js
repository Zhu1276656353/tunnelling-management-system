module.exports = {
    lines: [
        {
            name: '隧道增加数量',
            type: 'line',
            stack: 'Total',
            data: [183, 132, 101, 134, 90, 230, 210]
        },
        {
            name: '地质预测信息',
            type: 'line',
            stack: 'Total',
            data: [220, 182, 191, 234, 290, 330, 310]
        },
    ]
}