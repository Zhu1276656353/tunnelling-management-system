<template>
    <div class="top-nav">
        <div class="toggle-menu">
            <el-icon v-if="menuStore.isCollapse" @click="closeMenu(false)">
                <Expand />
            </el-icon>
            <el-icon v-else @click="openMenu(true)">
                <Fold />
            </el-icon>
        </div>
        <div class="breadcrumb">
            <el-breadcrumb :separator-icon="ArrowRight">
                <el-breadcrumb-item>{{$t("message.navs")}}</el-breadcrumb-item>
                <el-breadcrumb-item>{{ menuStore.breadcrumb }}</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="lang">
            <el-dropdown trigger="click">
                <span class="el-dropdown-link" style="outline: none;">
                    语言切换
                    <el-icon class="el-icon--right">
                        <arrow-down />
                    </el-icon>
                </span>
                <template #dropdown>
                    <el-dropdown-menu>
                        <el-dropdown-item @click="changeLang('zh')">中文</el-dropdown-item>
                        <el-dropdown-item @click="changeLang('en')">English</el-dropdown-item>
                    </el-dropdown-menu>
                </template>
            </el-dropdown>
        </div>
        <div class="user">
            <el-dropdown>
                <span class="el-dropdown-link" style="outline: none;">
                    {{ loginStore.username }}
                    <el-icon class="el-icon--right">
                        <arrow-down />
                    </el-icon>
                </span>
                <template #dropdown>
                    <el-dropdown-menu>
                        <el-dropdown-item @click="userCenter()">个人中心</el-dropdown-item>
                        <el-dropdown-item @click="existLogin()">退出登录</el-dropdown-item>
                    </el-dropdown-menu>
                </template>
            </el-dropdown>
        </div>
    </div>
</template>
<script setup>
import { ArrowRight } from '@element-plus/icons-vue'
import { useLoginStore } from '@/stores/loginStore';
import { useMenuStore } from '@/stores/menuStore';
import { useRouter } from 'vue-router';
/**
 * 退出登录：删除localStorage中的token、username、permission,切回到登录页面
 */
const loginStore = useLoginStore();
const router = useRouter();
const existLogin = () => {
    loginStore.token = '';
    loginStore.permission = '';
    loginStore.username = '';
    router.push('/login');
}
/**
 * 个人中心：跳转到个人中心页面
 */
const userCenter = () => {
    router.push('/userCenter');
}
// 关闭菜单折叠状态
const menuStore = useMenuStore();
const closeMenu = (flag) => {
    menuStore.isCollapse = flag
}
// 打开菜单折叠状态
const openMenu = (flag) => {
    menuStore.isCollapse = flag
}
//切换语言
const changeLang = (lang)=>{
    localStorage.setItem('lang',lang) 
    location.reload()
}
</script>
<style scoped>
.top-nav {
    width: 100%;
    height: 60px;
    padding-top: 17.5px;
    padding-left: 10px;
    box-sizing: border-box;
    background-color: #fff;
    box-shadow: 5px 0 5px rgba(0, 0, 0, 0.1);
}

.toggle-menu {
    font-size: 25px;
    cursor: pointer;
    float: left;
}

.breadcrumb {
    margin-left: 15px;
    margin-top: 5px;
    float: left;
}

.user {
    position: absolute;
    right: 20px;
    top: 20px;
}
.lang{
    margin-right: 120px;
    margin-top: 2.5px;
    float: right;
    font-size: 15px;
}
</style>