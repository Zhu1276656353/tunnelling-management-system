<template>
    <div class="drawer">
        <!-- 控制抽屉的按钮 -->
        <el-button class="setting-btn" @click="drawer = true" type="primary">
            <el-icon class="setting-icon">
                <Setting />
            </el-icon>
        </el-button>
        <!-- 抽屉组件 -->
        <el-drawer v-model="drawer" title="系统设置" size="20%">
            <span class="setting-title">LOGO的显示与隐藏</span>
            <el-switch v-model="systemStore.logoToggle" />
        </el-drawer>
    </div>
</template>
<script setup>
import { ref } from 'vue';
import { useSystemStore } from '@/stores/systemStore.js';
const systemStore = useSystemStore();
const drawer = ref(false)
</script>
<style scoped>
.drawer {
    position: fixed;
    right: 10px;
    top: 400px;
    z-index: 100;
    padding: 10px;
}

.setting-btn {
    width: 50px;
    height: 50px;
    border-radius: 50%;
}

.setting-icon {
    display: block;
    font-size: 30px;
}

.setting-title {
    float: left;
    margin-right: 15px;
    margin-top: 6px;
}
</style>