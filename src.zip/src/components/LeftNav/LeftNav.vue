<template>
     <div class="left-nav" :style="{ width: menuStore.isCollapse ? '64px' : '200px' }">
          <div v-show="systemStore.logoToggle" class="logo">{{ menuStore.isCollapse ? "隧道" : "隧道工程项目" }}</div>
          <el-menu :default-active="active" :collapse="menuStore.isCollapse" background-color="#545c64" router
               text-color="#fff" active-text-color="#ffd04b" class="el-menu-vertical-demo">
               <!-- 菜单项:通过服务器里的数据，index属性绑定菜单项的索引 -->
               <!-- template循环生成视图时，不会增加页面结构 -->
               <template v-for="(item, index) in menuStore.menus" :key="index">
                    <!-- 做个判断，如果item有children属性，则生成子菜单项，没有则生成无子菜单 -->
                    <el-sub-menu v-if="item.children" :index="item.path">
                         <template #title>
                              <component class="icon" :is="item.icon"></component>
                              <span>{{ item.name }}</span>
                         </template>
                         <el-menu-item :index="childItem.path" v-for="(childItem, chlidIndex) in item.children" :key="chlidIndex">
                              <span>{{ childItem.name }}</span>
                         </el-menu-item>
                    </el-sub-menu>
                    <el-menu-item v-else :index="item.path">·
                         <component class="icon" :is="item.icon"></component>
                         <span>{{ item.name }}</span>
                    </el-menu-item>
               </template>
          </el-menu>
     </div>
</template>
<script setup>
import { ref } from 'vue';
import { useMenuStore } from '@/stores/menuStore.js';
import { useSystemStore } from '@/stores/systemStore.js';
const active = ref("/")
const menuStore = useMenuStore();
const systemStore = useSystemStore();
//修复刷新页面的高亮设置
if (localStorage.getItem('active')) {
     active.value = localStorage.getItem('active')
}
</script>
<style scoped>
.left-nav {
     position: fixed;
     left: 0;
     top: 0;
     bottom: 0;
     width: 200px;
     background-color: #545c64;
     transition: 0.3s ease-in;
}

.logo {
     width: 100%;
     height: 60px;
     background-color: #6B6B7F;
     text-align: center;
     line-height: 60px;
     font-size: 25px;
     color: #fff;
     font-family: "华文中宋";
}

.el-menu {
     border-right: none;
}

.icon {
     width: 16px;
     height: 16px;
     margin-right: 5px;
}
</style>