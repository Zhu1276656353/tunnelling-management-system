export default {
    message:{
        navs:"current"
    }
}