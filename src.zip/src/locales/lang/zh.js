export default {
    message:{
        navs:"当前"
    }
}