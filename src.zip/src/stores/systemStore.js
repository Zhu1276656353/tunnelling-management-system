import { defineStore } from "pinia";
export const useSystemStore = defineStore("system", {
  state: () => ({
    //logo显隐
    logoToggle: true,
  }),
   persist: {
        enabled: true,
        key: 'systemStore', // 存储名称
        storage: localStorage, // 存储方式
    }
}); 