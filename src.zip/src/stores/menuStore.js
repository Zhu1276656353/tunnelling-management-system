import { defineStore } from "pinia";
export const useMenuStore = defineStore("menu",{
    state:()=>({
        isCollapse:false,//是否折叠
        breadcrumb:"首页",//面包屑导航
        menus:[],//菜单数据  在layout中存储
    }),
    persist: {
        enabled: true,
        key: 'menuStore', // 存储名称
        storage: localStorage, // 存储方式
    }
})