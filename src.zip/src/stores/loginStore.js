import { defineStore } from "pinia";
export const useLoginStore = defineStore("login", {
    state: () => ({
        token: "",
        username: "",
        permission: ""
    }),
    persist: {
        enabled: true,
        key: 'loginStore', // 存储名称
        storage: localStorage, // 存储方式
        paths: ['username', 'permission', 'token'] // 指定哪些状态需要被持久化
    }
})