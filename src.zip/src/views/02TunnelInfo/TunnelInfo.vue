<template>
    <div class="tunnelInfo-container">
        <div class="tunnelInfo-list">
            <p class="tunnelInfo-list-title">选择断面</p>
            <el-tree :load="loadNode" lazy :props="defaultProps" @node-click="handleNodeClick" />
        </div>
        <div class="tunnelInfo-content">
            <el-table :data="tunnelContent.data" stripe style="width: 100%">
                <el-table-column label="序号" prop="id" width="180" />
                <el-table-column label="隧道名称" prop="tunnelname" width="180" />
                <el-table-column label="图名" prop="imagename" />
                <el-table-column label="图号" prop="num" />
                <el-table-column label="操作">
                    <template #default="scope">
                        <el-button @click="previewHandler(scope.$index, scope.row)" type="danger"
                            size="small">预览</el-button>
                        <el-button @click="updateHandler(scope.$index, scope.row)" type="success"
                            size="small">上传</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
    <!-- 上传对话框 -->
    <el-dialog destroy-on-close center v-model="dialogUploadVisible" title="上传文件" width="500" >
        <el-upload v-model:file-list="fileList" class="upload" action="http://localhost:3000/api/upload" :limit="3"
            :on-success="handlePDFSuccess" :on-exceed="handleExceed">
            <el-button type="primary" size="small">上传</el-button>
        </el-upload>
        <template #footer>
            <div class="dialog-footer">
                <el-button @click="dialogUploadVisible = false">取消</el-button>
                <el-button type="primary" @click="dialogUploadVisible = false">
                    确定
                </el-button>
            </div>
        </template>
    </el-dialog>
</template>
<script setup>
import api from "@/api/index.js"
import { useRouter } from "vue-router"
import {  ref, reactive } from 'vue'
const defaultProps = {
    children: 'children',
    label: 'name',
}
const router = useRouter() 
//隧道信息内容
const tunnelContent = reactive({
    data: []
})
// 点击对应节点，获取隧道信息
const handleNodeClick = (data) => {
    // console.log(data)
    api.getTunnelContent({ content: data.content }).then((res) => {
        // console.log(res.data)
        if (res.data.status === 200) {
            tunnelContent.data = res.data.result
        } else {
            tunnelContent.data = []
        }
    }).catch(err => {
        console.log(err)
    })
}
// 获取隧道列表
const loadNode = (node, resolve) => {
    if (node.level === 0) {
        api.getTunnelList().then((res) => {
            if (res.data.status === 200) {
                resolve(res.data.result)
            } else {
                resolve([])
            }
        })
    }
    if (node.level === 1) {
        api.getTunnelListChild({ cid: node.data.cid }).then((res) => {
            if (res.data.status === 200) {
                resolve(res.data.result)
            } else {
                resolve([])
            }
        })
    }
    if (node.level > 1) {
        resolve([])
    }
}
const previewHandler = (index, row) => { 
    router.push("/pdf/"+row.id)
}
const fileList = ref([])
const dialogUploadVisible = ref(false)//上传文件对话框
//上传文件超出
const handleExceed = () => {

}
const currentID = ref(0)//当前上传文件ID
//上传成功回调
const handlePDFSuccess = (response, uploadFile) => {
    console.log(response)
    api.getUploadTunnelContent({ id: currentID.value, urlName: response.url.substr(7) }).then((res) => {

    }).catch((err) => {
        console.log(err)
    })
}
//点击上传按钮
const updateHandler = (index, row) => {
    currentID.value = row.id
    dialogUploadVisible.value = true
}
</script>
<style scoped>
.tunnelInfo-container {
    display: flex;
}

.tunnelInfo-list {
    width: 250px;
    background-color: #fff;
    padding: 10px;
    margin-right: 20px;
}

.tunnelInfo-list-title {
    font-size: 16px;
    text-align: center;
    font-weight: bold;
    padding: 7px;
    margin: -10px -10px 0 -10px;
    background-color: gray;
    color: #fff;
}

.tunnelInfo-content {
    flex: 1;
}

.upload {
    display: inline-block;
    padding: 20px;
}
</style>