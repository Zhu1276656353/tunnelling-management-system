<template>
    <!-- 搜索与添加 -->
    <div class="search">
        <span>项目状态:</span>
        <el-input class="input" @keyup.enter="searchHandler" v-model="searchInfo" size="large"
            placeholder="请输入要搜索的信息"></el-input>
        <el-button @click="searchHandler" class="button" size="large" type="primary" plain>搜索</el-button>
        <el-button @click="addHandler" class="button" size="large" type="primary" plain>添加</el-button>
    </div>
    <!-- 表格展示数据 -->
    <el-table :data="projectInfo.list" :header-cell-style="headerClass" stripe style="width: 100%">
        <el-table-column prop="name" label="项目名称" width="180" />
        <el-table-column prop="number" label="项目编码" width="120" />
        <el-table-column prop="address" label="项目地址" width="150" />
        <el-table-column prop="money" label="项目金额" width="120" />
        <el-table-column prop="duration" label="项目工期(月)" width="120" />
        <el-table-column :formatter="(value) => dateFormater(Number(value.startTime))" prop="startTime" label="开工日期"
            width="150" />
        <el-table-column :formatter="(value) => dateFormater(Number(value.endTime))" prop="endTime" label="终止日期"
            width="150" />
        <el-table-column prop="quantity" label="隧道数量" width="120" />
        <el-table-column prop="status" label="项目状态" width="120">
            <template #default="scope">
                <el-tag :type="scope.row.status === '1' ? 'primary' : 'success'">
                    {{ statusHandle(scope.row.status) }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="remark" label="备注" show-overflow-tooltip>
            <template #default="scope">
                <div v-html="scope.row.remark"></div>
            </template>
        </el-table-column>
        <el-table-column width="135" label="操作">
            <template #default="scope">
                <el-button size="small" @click="handleEdit(scope.$index, scope.row)">
                    编辑
                </el-button>
                <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">
                    删除
                </el-button>
            </template>
        </el-table-column>
    </el-table>
    <!-- 分页 -->
    <div class="page">
        <el-pagination @current-change="currentChangeHandler" background layout="prev, pager, next ,jumper"
            :total="total" :default-page-size="defaultPageSize" />
    </div>
    <!-- 添加数据的对话框 -->
    <el-dialog v-model="dialogAddVisible" title="添加隧道信息" width="35%" center>
        <el-form :inline="true" :model="addFormInfo">
            <el-form-item label="项目名称">
                <el-input v-model="addFormInfo.name" placeholder="请输入项目名称"></el-input>
            </el-form-item>
            <el-form-item label="项目编码">
                <el-input v-model="addFormInfo.number" placeholder="请输入项目编码"></el-input>
            </el-form-item>
            <el-form-item label="项目金额">
                <el-input v-model="addFormInfo.money" placeholder="请输入项目金额"></el-input>
            </el-form-item>
            <el-form-item label="项目地址">
                <el-input v-model="addFormInfo.address" placeholder="请输入项目地址"></el-input>
            </el-form-item>
            <el-form-item label="项目工期">
                <el-input v-model="addFormInfo.duration" placeholder="请输入项目工期"></el-input>
            </el-form-item>
            <el-form-item label="开工日期">
                <el-date-picker value-format="x" v-model="addFormInfo.startTime" type="date" placeholder="请选择开工日期" />
            </el-form-item>
            <el-form-item label="终止日期">
                <el-date-picker value-format="x" v-model="addFormInfo.endTime" type="date" placeholder="请选择终止日期" />
            </el-form-item>
            <el-form-item label="隧道数量">
                <el-input v-model="addFormInfo.quantity" placeholder="请输入隧道数量"></el-input>
            </el-form-item>
            <el-form-item label="项目状态">
                <el-input v-model="addFormInfo.status" placeholder="'0'已完工 - '1'施工中"></el-input>
            </el-form-item>
            <el-form-item label="项目备注">
                <TinymceEditor :options="options" @onDataEvent="getInfoEditorHandler"></TinymceEditor>
            </el-form-item>
        </el-form>
        <template #footer>
            <div class="dialog-footer">
                <el-button @click="dialogAddVisible = false">取消</el-button>
                <el-button type="primary" @click="sureHandler">确认</el-button>
            </div>
        </template>
    </el-dialog>
    <!-- 修改数据的对话框 -->
    <el-dialog destroy-on-close v-model="dialogEditVisible" title="编辑隧道信息" width="35%" center>
        <el-form :inline="true" :model="editFormInfo">
            <el-form-item label="项目名称">
                <el-input v-model="editFormInfo.name"></el-input>
            </el-form-item>
            <el-form-item label="项目编码">
                <el-input v-model="editFormInfo.number"></el-input>
            </el-form-item>
            <el-form-item label="项目金额">
                <el-input v-model="editFormInfo.money"></el-input>
            </el-form-item>
            <el-form-item label="项目地址">
                <el-input v-model="editFormInfo.address"></el-input>
            </el-form-item>
            <el-form-item label="项目工期">
                <el-input v-model="editFormInfo.duration"></el-input>
            </el-form-item>
            <el-form-item label="开工日期">
                <el-date-picker value-format="x" v-model="editFormInfo.startTime" type="date" />
            </el-form-item>
            <el-form-item label="终止日期">
                <el-date-picker value-format="x" v-model="editFormInfo.endTime" type="date" />
            </el-form-item>
            <el-form-item label="隧道数量">
                <el-input v-model="editFormInfo.quantity"></el-input>
            </el-form-item>
            <el-form-item label="项目状态">
                <el-input v-model="editFormInfo.status"></el-input>
            </el-form-item>
            <el-form-item label="项目备注">
                <TinymceEditor :editorID="editorID" :options="options" @onDataEvent="updateEditorHandler">
                </TinymceEditor>
            </el-form-item>
        </el-form>
        <template #footer>
            <div class="dialog-footer">
                <el-button @click="dialogEditVisible = false">取消</el-button>
                <el-button type="primary" @click="sureEditorHandler">确认</el-button>
            </div>
        </template>
    </el-dialog>
</template>
<script setup>
import api from '@/api/index.js'
import { ref, reactive, onMounted } from 'vue'
import { dateFormater } from '@/utils/utils.js'
import TinymceEditor from '@/components/TinymceEditor/TinymceEditor.vue'
const projectInfo = reactive({
    list: []
})
//初始化数据总条数
const total = ref(0)
//每页显示多少条数据
const defaultPageSize = ref(15)
onMounted(() => {
    // 页面加载时获取数据
    http(1)
    // 初始获取数据总数
    api.getTotal().then((res) => {
        if (res.data.status === 200) {
            total.value = res.data.result[0]["count(*)"]
        } else {
            total.value = 0
        }
    })
})
//网络请求
const http = (page) => {
    api.getProjectInfo({ page }).then((res) => {
        if (res.data.status === 200) {
            projectInfo.list = res.data.result
        }
    }).catch((err) => {
        console.log(err);
    })
}
//分页事件
const currentChangeHandler = (val) => {
    http(val)
}
//隧道状态文本
const statusHandle = (status) => {
    return status === '1' ? '施工中' : '已完工'
}
//表头样式
const headerClass = () => {
    return {
        background: '#dcdcdc',
        color: "#999",
        fontWeight: "bolder",
    }
}
//初始化  预修改表单数据
const editFormInfo = reactive({
    id: '',
    name: '',
    number: '',
    address: '',
    money: '',
    duration: '',
    startTime: '',
    endTime: '',
    quantity: '',
    status: '',
    remark: ''
})
const editorID = ref(0)//编辑器ID
//表格编辑按钮
const handleEdit = (index, row) => {
    dialogEditVisible.value = true
    editorID.value = row.id
    api.getPreUpdateProject({ id: row.id }).then((res) => {
        if (res.data.status === 200) {
            editFormInfo.id = res.data.result[0].id
            editFormInfo.name = res.data.result[0].name
            editFormInfo.number = res.data.result[0].number
            editFormInfo.address = res.data.result[0].address
            editFormInfo.money = res.data.result[0].money
            editFormInfo.duration = res.data.result[0].duration
            //修改时间格式
            editFormInfo.startTime = Number(res.data.result[0].startTime)
            editFormInfo.endTime = Number(res.data.result[0].endTime)
            editFormInfo.quantity = res.data.result[0].quantity
            editFormInfo.status = res.data.result[0].status
            editFormInfo.remark = res.data.result[0].remark
        } else {
            ElMessage({
                type: 'error',
                message: '获取数据失败',
            })

        }
    })
}

//表格删除按钮
const handleDelete = (index, row) => {
    ElMessageBox.confirm(
        '是否要删除此条数据?',
        '删除数据',
        {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
        }
    ).then(() => {
        //确定删除
        api.getDeleteProject({ id: row.id }).then((res) => {
            if (res.data.status === 200) {
                ElMessage({
                    type: 'success',
                    message: '删除成功',
                })
                http(1)
            } else {
                ElMessage({
                    type: 'error',
                    message: '删除失败',
                })
            }
        })
    }).catch(() => {
        ElMessage({
            type: 'info',
            message: '取消删除',
        })
    })

}
//搜索初始化状态
const searchInfo = ref('')
//搜索按钮事件
const searchHandler = () => {
    api.getSearch({ search: searchInfo.value }).then((res) => {
        if (res.data.status === 200) {
            projectInfo.list = res.data.result
        } else {
            projectInfo.list = []
        }
    })
}
/**
 * 添加对话框弹出事件
 */
//添加表单对话框控制
const dialogAddVisible = ref(false)
const dialogEditVisible = ref(false)//修改表单对话框控制
//初始化添加表单数据
const addFormInfo = reactive({
    name: '',
    number: '',
    address: '',
    money: '',
    duration: '',
    startTime: '',
    endTime: '',
    quantity: '',
    status: '',
    remark: ''
})

// 添加按钮事件
const addHandler = () => {
    dialogAddVisible.value = true
}
// 确认添加按钮事件
const sureHandler = () => {
    api.getAddProject({
        name: addFormInfo.name,
        number: addFormInfo.number,
        address: addFormInfo.address,
        money: addFormInfo.money,
        duration: addFormInfo.duration,
        startTime: addFormInfo.startTime,
        endTime: addFormInfo.endTime,
        quantity: addFormInfo.quantity,
        status: addFormInfo.status,
        remark: addFormInfo.remark
    }).then((res) => {
        if (res.data.status === 200) {
            dialogAddVisible.value = false
            http(1)
        } else {
            ElMessage.error(res.data.msg)
        }
    }).catch((err) => {
        console.log(err);
    })
}
//确认修改事件
const sureEditorHandler = () => {
    api.getUpdateProject(editorID.value, {
        name: editFormInfo.name,
        number: editFormInfo.number,
        address: editFormInfo.address,
        money: editFormInfo.money,
        duration: editFormInfo.duration,
        startTime: editFormInfo.startTime,
        endTime: editFormInfo.endTime,
        quantity: editFormInfo.quantity,
        status: editFormInfo.status,
        remark: editFormInfo.remark //富文本编辑器中数据
    }).then((res) => {
        if (res.data.status === 200) {
            dialogEditVisible.value = false
            http(1)
        } else {
            ElMessage.error(res.data.msg)
        }
    })
}
//提交修改富文本编辑器
const updateEditorHandler = (data)=>{
    editFormInfo.remark = data
}
//富文本编辑器宽度高度
const options = ref({
    width: '100%',
    height: '300px',
})
//获取富文本编辑器数据
const getInfoEditorHandler = (data) => {
    addFormInfo.remark = data
}
</script>
<style scoped>
.search {
    margin-top: 10px;
    box-sizing: border-box;
    padding: 10px;
    width: 100%;
    background-color: #fff;
}

.search span {
    font-weight: bold;
}

.search .input {
    width: 300px;
    margin-left: 10px;
}

.page {
    position: fixed;
    right: 20px;
    bottom: 100px;
}
</style>