<template>
    <div class="layout-container">
        <Drawer></Drawer>
        <LeftNav></LeftNav>
        <div class="right-container" :style="{ marginLeft: menuStore.isCollapse ? '64px' : '200px' }">
            <TopNav></TopNav>
            <div class="content">
                <RouterView></RouterView>
            </div>
        </div>
    </div>
</template>
<script setup>
import LeftNav from '@/components/LeftNav/LeftNav.vue';
import TopNav from '@/components/TopNav/TopNav.vue';
import { useMenuStore } from '@/stores/menuStore';
import { useLoginStore } from '@/stores/loginStore';
import { RouterView } from 'vue-router';
import { onMounted } from 'vue';
import api from '@/api/index.js';
// 动态添加manageRouter路由
import { useRouter } from 'vue-router';
import manageRouter from '@/router/dynamicRoute.js';
import Drawer from '@/components/Drawer/Drawer.vue';

const menuStore = useMenuStore();
const loginStore = useLoginStore();
const router = useRouter();
// 在组件挂载完成后，调用 api.getRouter 方法获取当前用户对应的路由数据(getRouter是api中定义的一个方法，用于获取路由数据)
// 传入参数 { user: loginStore.permission }，表示根据当前用户的权限获取对应的菜单和路由信息
onMounted(() => {
    api.getRouter({ user: loginStore.permission }).then((res) => {
        if (res.data.status === 200) {
            menuStore.menus = res.data.menuData.menus;
            //判断当前用户权限
            if (loginStore.permission === 'admin') {
                router.addRoute('layout', manageRouter)//添加管理员路由
            }
        }
    }).catch((error) => {
        console.error("Failed to fetch menu data:", error);
    });
})
</script>
<style scoped>
.right-container {
    margin-left: 200px;
    transition: 0.3s ease-in;
}

.content {
    padding: 10px;
}
</style>