<template>
    <div class="add-user">
        <span>用户状态:</span>
        <el-input class="input" @keyup.enter="searchHandler" v-model="searchInfo" size="large"
            placeholder="请输入用户信息"></el-input>
        <el-button class="button" type="primary" size="large" style="margin-left: 10px;" plain
            @click="searchHandler">查询</el-button>
        <el-button class="button" type="primary" size="large" plain @click="addHandler">添加</el-button>
    </div>
    <el-table :data="userList.list" stripe style="width: 100%">
        <el-table-column prop="id" label="ID" width="180" />
        <el-table-column prop="username" label="用户姓名" width="200" />
        <el-table-column label="权限" width="200">
            <template #default="scope">
                <div>{{ scope.row.permission === 'admin' ? '管理员' : '普通用户' }}</div>
            </template>
        </el-table-column>
        <el-table-column prop="phone" label="手机号" width="200" />
        <el-table-column label="操作">
            <template #default="scope">
                <el-button size="small" @click="handleEditor(scope.$index, scope.row)" :disabled="scope.row.id === 1">
                    编辑
                </el-button>
                <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)"
                    :disabled="scope.row.id === 1">
                    删除
                </el-button>
            </template>
        </el-table-column>
    </el-table>
    <!-- 添加用户视图 -->
    <el-dialog v-model="dialogAddVisible" title="添加用户" Width="25%" center>
        <el-form :model="userForm" status-icon stripe label-width="120px" style="padding: 50px!important;">
            <el-form-item label="用户名" prop="username">
                <el-input v-model="userForm.username" type="text"></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="password">
                <el-input v-model="userForm.password" type="password" show-password></el-input>
            </el-form-item>
            <el-form-item label="权限" prop="permission">
                <el-radio-group v-model="userForm.permission" size="large">
                    <el-radio-button @click="permissionHandler('admin')" value="管理员">管理员</el-radio-button>
                    <el-radio-button @click="permissionHandler('vip')" value="普通用户">普通用户</el-radio-button>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="手机号" prop="phone">
                <el-input v-model="userForm.phone" type="text"></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <el-button @click="dialogAddVisible = false">取消</el-button>
            <el-button type="primary" @click="sureAddUserHandler">确定</el-button>
        </template>
    </el-dialog>
    <!-- 更新数据模态框 -->
    <el-dialog v-model="dialogUpdateVisible" title="修改用户" Width="25%" center>
        <el-form :model="userUpdateForm" status-icon stripe label-width="120px" style="padding: 50px!important;">
            <el-form-item label="用户名" prop="username">
                <el-input v-model="userUpdateForm.username" type="text" disabled></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="password">
                <el-input v-model="userUpdateForm.password" type="password" show-password></el-input>
            </el-form-item>
            <el-form-item label="权限" prop="permission">
                <el-radio-group v-model="userUpdateForm.permission" size="large">
                    <el-radio-button @click="permissionUpdateHandler('admin')" value="admin">管理员</el-radio-button>
                    <el-radio-button @click="permissionUpdateHandler('vip')" value="vip">普通用户</el-radio-button>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="手机号" prop="phone">
                <el-input v-model="userUpdateForm.phone" type="text"></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <el-button @click="dialogUpdateVisible = false">取消</el-button>
            <el-button type="primary" @click="sureUpdateUserHandler">确定</el-button>
        </template>
    </el-dialog>
</template>
<script setup>
import api from "@/api/index.js";
import { onMounted, reactive, ref } from "vue";
const userList = reactive({
    list: []
})
onMounted(() => {
    http()
})
const http = () => {
    api.getUserList().then((res) => {
        if (res.data.status === 200) {
            userList.list = res.data.result
        } else {
            console.log("获取用户列表失败")
        }
    }).catch((err) => {
        console.log(err)
    })
}
// 搜索内容
const searchInfo = ref("")
// 搜索按钮
const searchHandler = () => {
    api.getUserSearch({ search: searchInfo.value }).then((res) => {
        if (res.data.status === 200) {
            userList.list = res.data.result
        } else {
            console.log("获取用户列表失败")
        }
    }).catch((err) => {
        console.log(err)
    })
}
// 用户列表
const userForm = reactive({
    username: "",
    password: "",
    permission: "vip",
    phone: ""
})
const dialogAddVisible = ref(false)//增加用户视图
//增加按钮
const addHandler = () => {
    dialogAddVisible.value = true
}
//确定添加按钮
const sureAddUserHandler = () => {
    api.getUserAdd({
        username: userForm.username,
        password: userForm.password,
        permission: userForm.permission,
        phone: userForm.phone
    }).then((res) => {
        if (res.data.status === 200) {
            ElMessage.success(res.data.message)
            dialogAddVisible.value = false
            http()
        } else {
            ElMessage.error(res.data.message)
        }
    })
}
/**
 * 用户更新：把添加用户里的数据全部修改为更新的数据
 * 
 */
const userUpdateForm = reactive({//用户更新表单
    id: "",
    username: "",
    password: "",
    permission: "vip",
    phone: ""
})
const permissionHandler = (value) => {//权限选择框
    userForm.permission = value
}
const dialogUpdateVisible = ref(false)//更新弹窗

const permissionUpdateHandler = (value) => {// 用户更新权限选择
    userUpdateForm.permission = value
}
const updateID = ref(0)//定义点击编辑时对应的id
//预更新用户
const handleEditor = (index, row) => {
    updateID.value = row.id
    if (row.id === 1) {
        ElMessage.warning('不能编辑管理员账户')
        return
    }
    dialogUpdateVisible.value = true
    api.getUserPreview({ id: row.id }).then((res) => {
        if (res.data.status === 200) {
            userUpdateForm.username = res.data.result.username
            userUpdateForm.password = res.data.result.password
            userUpdateForm.permission = res.data.result.permission
            userUpdateForm.phone = res.data.result.phone
        }
    })

}
//确定更新用户
const sureUpdateUserHandler = () => {
    api.getUserUpdate({
        id: updateID.value,
        password: userUpdateForm.password,
        permission: userUpdateForm.permission,
        phone: userUpdateForm.phone
    }).then((res) => {
        console.log(res.data)
        if (res.data.status === 200) {
            ElMessage.success("更新成功")
            dialogUpdateVisible.value = false
            http()
        } else {
            ElMessage.error("更新失败")
        }
    })
}
/**
 * 用户删除
 * 
 */
const handleDelete = (index, row) => {
    ElMessageBox.confirm(
        '您确定要删除该用户吗',
        '删除用户',
        {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
        }
    )
        .then(() => {
            api.getUserDelete({ id: row.id }).then((res) => {
                if (res.data.status === 200) {
                    ElMessage({
                        type: 'success',
                        message: '删除成功',
                    })
                    http()
                } else {
                    ElMessage({
                        type: 'error',
                        message: '删除失败',
                    })
                }
            })
        })
        .catch(() => {
            ElMessage({
                type: 'info',
                message: '取消删除',
            })
        })

}
</script>
<style scoped>
.add-user {
    margin: 10px 0;
    padding: 10px;
    width: 100%;
    background: #fff;
    box-sizing: border-box;
}

.add-user span {
    font-weight: bold;
}

.add-user .input {
    width: 300px;
    margin-left: 10px;
}
</style>