<template>
    <div class="card">
        <div class="box">
            <el-icon class="box-icon" style="color:#409eff;">
                <Document />
            </el-icon>
            <span class="box-title">隧道数量:1000</span>
        </div>
        <div class="box">
            <el-icon class="box-icon" style="color:#e7a5a5;">
                <Odometer />
            </el-icon>
            <span class="box-title">检验合格:805</span>
        </div>
        <div class="box">
            <el-icon class="box-icon" style="color:#aac48e;">
                <Bell />
            </el-icon>
            <span class="box-title">正在施工:304</span>
        </div>
        <div class="box">
            <el-icon class="box-icon" style="color:#8f88ca;">
                <Clock />
            </el-icon>
            <span class="box-title">地质预报:3450</span>
        </div>
    </div>
    <div class="line" id="line"></div>
    <div class="charts">
        <div class="radar charts-box" id="radar"></div>
        <div class="pie charts-box" id="pie"></div>
        <div class="bar charts-box" id="bar"></div>
    </div>
</template>
<script setup>
//导入echarts插件
import { getCurrentInstance, onMounted } from 'vue'
import api from '@/api/index.js'
const { proxy } = getCurrentInstance()
onMounted(() => {
    //获取line图表数据
    api.getLineData().then((res) => {
        if (res.data.status === 200) {
            //调用echarts插件
            proxy.$line("line", res.data.result.lines);
        }
    }).catch((err) => {
        console.error(err)
    }),
    //获取雷达图数据
    api.getRadarData().then((res)=>{
        if(res.data.status === 200){
            //调用echarts插件
            proxy.$radar("radar", res.data.result.radar);
        }
    }).catch((err) => {
        console.error(err)
    }),
    //获取饼图数据
    api.getPieData().then((res)=>{
        if(res.data.status === 200){
            //调用echarts插件
            proxy.$pie("pie", res.data.result.pie);
        }
    }).catch((err) => {
        console.error(err)
    }),
    //获取柱状图数据
    api.getBarData().then((res)=>{
        if(res.data.status === 200){
            //调用echarts插件
            proxy.$bar("bar", res.data.result.bar);
        }
    }).catch((err) => {
        console.error(err)
    })
})

</script>
<style scoped>
.card {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.card .box {
    width: 22%;
    height: 130px;
    padding: 20px;
    background-color: #fff;
}

.card .box-icon {
    display: block;
    font-size: 80px;
    color: #8f88ca;
    line-height: 130px;
    float: left;
    padding-left: 20px;
}

.card .box-title {
    display: block;
    font-size: 20px;
    color: #666;
    line-height: 130px;
    float: right;
    padding-right: 20px;
}

.line {
    width: 100%;
    height: 300px;
    background-color: #fff;
    margin-top: 20px;
}

.charts {
    width: 100%;
    height: 430px;
    background-color: #fff;
    margin-top: 20px;
    padding: 20px;
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.charts-box {
    width: 30%;
    height: 100%;
    float: left;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}
</style>