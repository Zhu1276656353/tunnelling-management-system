<template>
    <div class="china" id="china"></div>
</template>
<script setup>
import { getCurrentInstance, onMounted } from 'vue'
const { proxy } = getCurrentInstance()
onMounted(() => {
    proxy.$chinaMap("china", china)
})
</script>
<style scoped>
.china {
    width: 1200px;
    height: 900px;
    background-color: #fff;
    margin: 0 auto;
}
</style>