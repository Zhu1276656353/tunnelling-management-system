<template>
    <!-- 登录页面的外层容器，用于包裹整个登录表单 -->
    <div class="login-container">
        <!-- 使用 Element Plus 的 el-form 组件实现登录表单 -->
        <el-form class="user-container" size="large" :userData="user">
            <!-- 标题区域 -->
            <div class="title-container">
                <!-- 登录标题 -->
                <p class="title">隧道后台管理系统登录</p>
            </div>

            <!-- 用户名输入框 -->
            <el-form-item prop="username">
                <el-input type="text" v-model="user.username" placeholder="请输入用户名" clearable>
                    <template #prepend><el-icon>
                            <User />
                        </el-icon></template>
                </el-input>
            </el-form-item>

            <!-- 密码输入框 -->
            <el-form-item prop="password">
                <el-input type="password" v-model="user.password" placeholder="请输入密码" show-password clearable>
                    <template #prepend><el-icon>
                            <Lock />
                        </el-icon></template>
                </el-input>
            </el-form-item>

            <!-- 登录按钮 -->
            <el-button type="primary" style="width: 100%;" @click="login" :plain="true">登&nbsp;&nbsp;&nbsp;录</el-button>
        </el-form>
    </div>
</template>
<script setup>
import { reactive } from 'vue'
// 引入封装的 API 接口模块，用于发送登录请求
import api from "../../api/index.js"
import { useRouter } from 'vue-router'
import { useLoginStore } from '@/stores/loginStore.js'
const router = useRouter()
const loginStore = useLoginStore()
const user = reactive({
    username: 'admin', // 用户输入的用户名
    password: '123456'  // 用户输入的密码
})

function login() {
    // 调用封装的 API 方法 getLogin，传入用户名和密码进行登录请求
    api.getLogin({
        username: user.username,
        password: user.password
    }).then((res) => {
        if (res.data.status === 200) {
            // 将返回的 token、用户名和权限信息保存到 Pinia 的 loginStore 中
            loginStore.token = res.data.token
            loginStore.username = res.data.username
            loginStore.permission = res.data.permission
            router.push('/')// 使用 router.push 跳转到首页（路径为 '/'）
        } else {
            // 如果登录失败，使用 Element Plus 的 ElMessage 提示错误信息
            ElMessage.error(res.data.msg)
        }
    })
}
</script>
<style scoped>
.login-container {
    width: 100%;
    height: 100%;
    background-color: #2b3a4b;
}

.user-container {
    width: 400px;
    position: relative;
    left: 50%;
    top: 40%;
    transform: translate(-50%, -50%);
    background-color: #fff;
    padding: 30px !important;
    border-radius: 30px 10px;
}

.title-container .title {
    font-size: 25px;
    font-family: "华文中宋";
    text-align: center;
    margin-bottom: 20px;
}
</style>