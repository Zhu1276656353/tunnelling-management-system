<template>
  <RouterView></RouterView>
</template>

<script setup>
import { RouterView } from 'vue-router';
</script>

<style>
/* 公共样式 */
body,html,#app{
  height: 100%;
}
/* 修改dialog中header样式 */
.el-dialog{
  padding: 0!important;
}
.el-form{
  /* padding: 20px!important; */
  padding: 20px 20px 0px 50px!important;
}
.el-dialog__header{
  background-color: gray;
  padding-top: 15px;
}
.el-dialog__header span{
  color: white;
}
.el-dialog__footer{
  padding: 10px 0 20px 0!important;
}
</style>