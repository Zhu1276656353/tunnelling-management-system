/**
 * echarts图标库
 */
import * as echarts from 'echarts'
import china from "@/assets/json/china.json"
export default {
    //echarts挂载到vue全局
    install: app => {
            //折现图
            app.config.globalProperties.$line = (element, data) => {
                //加载echarts图表
                var myChart = echarts.init(document.getElementById(element));
                const option = {
                    tooltip: {
                        trigger: 'axis'
                    },
                    legend: {
                        data: ['隧道增加数量', '地质预测信息']
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    toolbox: {
                        feature: {
                            saveAsImage: {}
                        }
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: data//homeView传来的数据
                };
                myChart.setOption(option);
            },
            //雷达图
            app.config.globalProperties.$radar = (element, data) => {
                var myChart = echarts.init(document.getElementById(element));
                const option = {
                    legend: {
                        data: ['Allocated Budget', 'Actual Spending']
                    },
                    radar: {
                        indicator: [
                            { name: 'Sales' },
                            { name: 'Administration' },
                            { name: 'Information Technology' },
                            { name: 'Customer Support' },
                            { name: 'Development' },
                            { name: 'Marketing' }
                        ]
                    },
                    series: data//homeView传来的数据
                }
                myChart.setOption(option);
            },
            //饼图
            app.config.globalProperties.$pie = (element, data) => {
                var myChart = echarts.init(document.getElementById(element));
                const option = {
                    legend: {
                        top: 'bottom'
                    },
                    toolbox: {
                        show: true,
                        feature: {
                            mark: { show: true },
                            dataView: { show: true, readOnly: false },
                            restore: { show: true },
                            saveAsImage: { show: true }
                        }
                    },
                    series: data
                };
                myChart.setOption(option);

            },
            //柱状图
            app.config.globalProperties.$bar = (element, data) => {
                var myChart = echarts.init(document.getElementById(element));
                const option = {
                    xAxis: {
                        type: 'category',
                        data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series:data
                }
                myChart.setOption(option);
            },
            // 中国地图
            app.config.globalProperties.$chinaMap = (element, data) => {
                var myChart = echarts.init(document.getElementById(element));
                // 注册中国地图
                echarts.registerMap('china', china);
                const option = { 
                    //鼠标点击弹窗
                    tooltip: { 
                        triggerOn:"click",//鼠标点击触发
                        enterable: true, //是否出现弹窗
                    },
                    visualMap:{
                        origin:"vertical",
                        type:"piecewise",//分段型
                        pieces:[
                            {min:0,max:0,color:"#fff"},
                            {min:0,max:10,color:"#fdfdcf"},
                            {min:10,max:20,color:"#fe9e83"},
                            {min:20,max:30,color:"#e55a4e"},
                            {min:30,max:40,color:"#4f070d"},
                            {min:40,max:100,color:"#ff0000"},
                        ]
                    },
                    series:[
                        {
                            name:"中国地图",
                            type:"map",
                            map: 'china',
                            roam: false,//鼠标滚轮是否可以缩放
                            zoom: 1.2,//缩放比例
                            label:{
                                show: true, //是否显示省份名称
                                fontSize: 8,
                                color: "#000"
                            },
                            itemStyle:{
                                areaColor: "#fff", //地图区域颜色
                                borderColor: "rgba(0,0,0,0.5)",//地图边框颜色
                            },
                            data:[
                            {name: '北京',value: 10},
                            {name: '天津',value: 20},
                            {name: '上海',value: 30},
                            {name: '重庆',value: 40},
                            {name: '河北',value: 50},
                            {name: '河南',value: 60},
                            {name: '云南',value: 70},
                            ]
                        }
                    ]
                };
                myChart.setOption(option);
            }
    }
}