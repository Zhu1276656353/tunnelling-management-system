import base from './base.js'
import axios from '@/utils/request.js'

const api = {
    //登录
    getLogin(params) {
        return axios.post(base.baseUrl + base.login, params)
    },
    //用户权限
    getRouter(params) {
        return axios.get(base.baseUrl + base.router, {
            params
        })
    },
    //线条数据
    getLineData(params) {
        return axios.get(base.baseUrl + base.lineData, params)
    },
    //饼图数据
    getPieData(params) {
        return axios.get(base.baseUrl + base.pieData, params)
    },
    //雷达图数据
    getRadarData(params) {
        return axios.get(base.baseUrl + base.radarData, params)
    },
    //柱状图数据
    getBarData(params) {
        return axios.get(base.baseUrl + base.barData, params)
    },
    //隧道信息查询
    getProjectInfo(params) {
        return axios.get(base.baseUrl + base.projectInfo, {
            params
        })
    },
    //隧道信息搜索
    getSearch(params) {
        return axios.get(base.baseUrl + base.search, {
            params
        })
    },
    //隧道信息总数
    getTotal(params) {
        return axios.get(base.baseUrl + base.total, {
            params
        })
    },
    //隧道信息添加
    getAddProject(params) {
        return axios.get(base.baseUrl + base.addProject, { params })
    },
    //隧道信息删除
    getDeleteProject(params) {
        return axios.get(base.baseUrl + base.deleteProject, { params })
    },
    //预更新
    getPreUpdateProject(params) {
        return axios.get(base.baseUrl + base.preUpdateProject, { params })
    },
    //更新
    getUpdateProject(id, params) {
        return axios.put(base.baseUrl + base.updateProject + id, params)
    },
    //隧道信息列表 一级
    getTunnelList() {
        return axios.get(base.baseUrl + base.tunnelList)
    },
    //隧道信息列表 一级
    getTunnelListChild(params) {
        return axios.get(base.baseUrl + base.tunnelListChild, { params })
    },
    //隧道设计信息 内容
    getTunnelContent(params) {
        return axios.get(base.baseUrl + base.tunnelContent, { params })
    },
    //隧道设计信息--上传
    getUploadTunnelContent(params) {
        return axios.get(base.baseUrl + base.uploadTunnelContent, { params })
    },
    //隧道设计信息--pdf预览
    getPdfPreview(params) {
        return axios.get(base.baseUrl + base.pdfPreview, { params })
    },
    //获取用户列表
    getUserList(params) {
        return axios.get(base.baseUrl + base.userList, { params })
    },
    //用户搜索
    getUserSearch(params) {
        return axios.get(base.baseUrl + base.userSearch, { params })
    },
    //增加用户
    getUserAdd(params) {
        return axios.get(base.baseUrl + base.userAdd, { params })
    },
    //删除用户
    getUserDelete(params) {
        return axios.get(base.baseUrl + base.userDelete, { params })
    },
    //预更新用户
    getUserPreview(params){
        return axios.get(base.baseUrl + base.userPreview, { params })
    },
    //用户更新
    getUserUpdate(params) {
        return axios.get(base.baseUrl + base.userUpdate, { params })
    },
}
export default api