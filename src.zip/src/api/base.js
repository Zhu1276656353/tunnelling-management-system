/**
 * 存放所有网络请求地址
 */
const base = {
    baseUrl: "http://localhost:3000",//公共地址
    login: "/api/login",// 登录地址
    router:"/api/router",// 用户权限地址
    lineData:"/api/lineData",// 线条数据地址
    pieData:"/api/pieData",// 饼状数据地址
    radarData:"/api/radarData",// 雷达图数据地址
    barData:"/api/barData",// 柱状图数据地址
    projectInfo:"/api/project/all",// 隧道信息查询地址
    search:"/api/project/search",// 隧道信息搜索地址
    total:"/api/project/total",// 隧道信息总数地址
    addProject:"/api/project/add",// 隧道信息添加地址
    deleteProject:"/api/project/delete",// 隧道信息删除地址
    preUpdateProject:"/api/project/preUpdate",// 隧道信息预修改地址
    updateProject:"/api/project/update/",// 隧道信息修改地址
    tunnelList:"/api/tunnel/list",// 隧道设计信息 一级 tree
    tunnelListChild:"/api/tunnel/list/child",//隧道设计信息 二级 tree
    tunnelContent:"/api/tunnel/content",// 隧道设计信息 内容
    uploadTunnelContent:"/api/tunnel/content/url",// 隧道设计信息 上传
    pdfPreview:"/api/tunnel/pdf",// 隧道设计信息 pdf预览
    userList:"/api/user/list",// 用户列表
    userSearch:"/api/user/search",//查询客户
    userAdd:"/api/user/add",// 添加用户
    userDelete:"/api/user/delete",// 删除用户
    userPreview:"/api/user/preview",// 用户信息预览
    userUpdate:"/api/user/update",// 修改用户
}
export default base