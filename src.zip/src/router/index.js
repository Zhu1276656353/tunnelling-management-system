import { createRouter, createWebHistory } from 'vue-router'
import LayOut from '@/views/LayOut.vue'//除了登录页面，所有页面都放在LayOut.vue中
import HomeView from '@/views/00HomeView/HomeView.vue'
import LoginView from "@/views/LoginView.vue/LoginView.vue"
import { useLoginStore } from '@/stores/loginStore.js'
import { useMenuStore } from '@/stores/menuStore.js'
const router = createRouter({
  linkActiveClass: 'active',
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/login",
      name: 'login',
      component: LoginView
    },
    {
      path:"/pdf/:id",
      name:"pdf",
      component:()=>import("@/views/02TunnelInfo/PDFViewer/PDFViewer.vue")
    },
    {
      //404路径匹配规则：没有找到对应的路径地址
      path: "/:pathMatch(.*)*",
      name: 'notFound',
      component: () => import('@/views/NotFound/NotFound.vue'),
    },
    {
      path: '/',
      name: 'layout',
      component: LayOut,
      meta: {
        requireAuth: true
      },
      children: [
        {
          path: "/",
          name: "home",
          meta: {
            requireAuth: true,
            key: "首页"
          },
          component: HomeView,
        },
        {
          path: "/projectInfo",
          name: "projectInfo",
          component: () => import('@/views/01ProjectInfo/ProjectInfo.vue'),
          meta: {
            requireAuth: true,
            key: "项目基础信息"
          },
        },
        {
          path: "/tunnelInfo",
          name: "tunnelInfo",
          component: () => import('@/views/02TunnelInfo/TunnelInfo.vue'),
          meta: {
            requireAuth: true,
            key: "隧道设计信息"
          },
        },
        {
          path: "/buildManageInfo",
          name: "buildManageInfo",
          component: () => import('@/views/04BuildManageInfo/BuildManageInfo.vue'),
          meta: {
            requireAuth: true,
            key: "施工监控检测"
          }
        },
        {
          path: "/geographyInfo",
          name: "geographyInfo",
          component: () => import('@/views/05GeographyInfo/GeographyInfo.vue'),
          meta: {
            requireAuth: true,
            key: "超前地质预报"
          },
        },
        {
          path: "/systemManage",
          name: "systemManage",
          component: () => import('@/views/06SystemManage/SystemManage.vue'),
          meta: {
            requireAuth: true,
            key: "系统信息管理"
          },
        },
        {
          path: "/userCenter",
          name: "userCenter",
          component: () => import('@/views/UserCenter/UserCenter.vue'),
          meta: {
            requireAuth: true,
            key: "个人中心"
          },
        },
        {
          path: "/plan",
          name: "plan",
          component: () => import('@/views/04BuildManageInfo/PlanTest/PlanTest.vue'),
          meta: {
            requireAuth: true,
            key: "检测计划"
          },
        },
        {
          path: "/section",
          name: "section",
          component: () => import('@/views/04BuildManageInfo/SectionTest/SectionTest.vue'),
          meta: {
            requireAuth: true,
            key: "切面检测"
          },
        }
      ]
    }
  ],
})
// 在路由跳转之前进行验证
router.beforeEach((to, form, next) => {
  if (to.meta.requireAuth) {
    const loginStore = useLoginStore()
    let token = loginStore.token
    if (token) {
      next()
    } else {
      next({
        path: '/login'
      })
    }
  } else {
    next()
  }
})
//实现面包屑导航
router.afterEach((to, form) => {
  localStorage.setItem('active', to.path)
  if (to.meta.key) {
    const menuStore = useMenuStore()
    menuStore.breadcrumb = to.meta.key
  }
})
export default router
