const manage = {
    path: "/workManageInfo",
    name: "workManageInfo",
    component: () => import('@/views/03WorkManageInfo/WorkManageInfo.vue'),
    meta: {
        requireAuth: true,
        key: "工作监督管理"
    },
}
export default manage;