import "./assets/initial.css"//初始化样式
import { createApp } from 'vue'//引入vue
import * as ElementPlusIconsVue from '@element-plus/icons-vue'//引入element-plus中icon图标
import echarts from "./plugin/echarts"//引入echarts图表库
import i18n from "./locales/i18n.js"
import ElementPlus from 'element-plus'
import zh from 'element-plus/dist/locale/zh-cn.mjs'//引入element-plus中文包
import en from 'element-plus/dist/locale/en.mjs'//引入element-plus英文包

import { createPinia } from 'pinia'//引入pinia
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';//引入pinia持久化插件
const pinia = createPinia();
pinia.use(piniaPluginPersistedstate);

import App from './App.vue'
import router from './router'

const app = createApp(App)
//引入element-plus中icon图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}
//引入pinia
app.use(pinia)
//引入路由
app.use(router)
//引入echarts图表库
app.use(echarts)
//国际化语言
app.use(i18n)
app.mount('#app')
//组件国际化
app.use(ElementPlus, {
  locale: localStorage.getItem('lang') === 'zh' ? zh : en,
})
export default pinia;
